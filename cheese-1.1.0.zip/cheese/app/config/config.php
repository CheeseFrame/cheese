<?php
    //DB Params
    define('DB_HOST','localhost');
    define('DB_USER','_YOUR_USER_');
    define('DB_PASS', '_YOUR_PASS_');
    define('DB_NAME', '_YOUR_DBNAME_');
    
    
    //App Root
    define('APPROOT', dirname(dirname(__FILE__)));
    // URL Root
    define('URLROOT', "_YOUR_URL_");
    // Site Name
    define('SITENAME','Welcome to Cheese');
    // App Version
    define('APPVERSION','1.1.0');


    // Controller
    define ('CONTROLLER','Pages');

    // Method
    define ('METHOD','index');