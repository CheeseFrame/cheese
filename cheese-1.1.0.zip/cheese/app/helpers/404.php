<?php

	function show404(){
		include '../app/views/def/404.php';
	}