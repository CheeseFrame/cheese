<?php
    require_once '../app/bootstrap.php';
    // Instantiation of Core class
    $init = new Core;

