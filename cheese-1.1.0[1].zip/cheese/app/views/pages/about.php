<?php include APPROOT . '/views/incl/header.blade.php';?>
    <div class="container text-center">

        <h1 class='cheese'><?php echo $data['title']; ?></h1>
        <p class='lead'><?php echo $data['description']; ?></p>
    </div>
<?php include APPROOT . '/views/incl/footer.blade.php';?>